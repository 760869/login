package com.controller;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.model.Register;
import com.service.AuthService;
 
@Controller
@RequestMapping("/user")

public class LoginCtrl {
	 @Autowired
	    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
	 
	    private static Logger log = Logger.getLogger(LoginCtrl.class);
	 
	    // Checks if the user credentials are valid or not.
	    @RequestMapping(value = "/validate", method = RequestMethod.POST)
	    public ModelAndView validateUsr(@RequestParam("username")String username, @RequestParam("password")String password) {
	        String msg = "";
	        boolean isValid = authenticateService.findUser(username, password);
	        log.info("Is user valid?= " + isValid);
	 
	        if(isValid) {
	            msg = "Welcome " + username + "!";
	            return new ModelAndView("result", "output", msg);
	        } else {
	            msg = "Invalid credentials";
	            return new ModelAndView("invalid", "output", msg);
	        }
	 
	     
	    }
	    
	    //testing for register
	    
	    @RequestMapping(value = "/registerlink")
		public ModelAndView redirectregister()
		{
			System.out.println("In the /registerlink");
	    	return new ModelAndView("register");
		}
		
		 @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
		    public ModelAndView RegisterUsr(@RequestParam("firstname")String firstname, @RequestParam("lastname")String lastname,@RequestParam("email")String email,@RequestParam("psw")String psw) {
		       
		        Register reg = new Register();
		        reg.setEmail(email);
		        reg.setFirstname(firstname);
		        reg.setLastname(lastname);
		        reg.setPsw(psw);
		       
		      
		        boolean isValid = authenticateService.registeruser(reg);
		             
		 
		        if(isValid) {
		        	return new ModelAndView("index");
		        } else {
		        	return new ModelAndView("register");
		        }
		 
		        
		    }
	}


